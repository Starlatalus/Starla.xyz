# SENTINEL — Discord Bot Security Dashboard

A dark-themed, mobile-friendly security dashboard front-end for a Discord moderation/anti-nuke bot. Plain HTML/CSS/JS — no build step, no framework.

## Features (v1)
- Dark security theme with HUD-style background grid
- Server security score gauge (animated, color-coded)
- Anti-Nuke status card
- AutoMod status card
- Backup status card
- Moderation logs panel (terminal-style feed with filters)
- Settings cards (toggles, thresholds, trusted roles, alerts, access)
- Fully responsive — collapses to an off-canvas mobile nav

## Running it locally
No build tools needed. Either:

```bash
# just open it
open index.html

# or serve it (recommended, avoids any local file/CORS quirks)
python3 -m http.server 8080
# then visit http://localhost:8080
```

## Deploying on GitHub Pages
1. Push this folder to a GitHub repo.
2. Repo → **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Save — your dashboard will be live at `https://<username>.github.io/<repo>/` in a minute or two.

## Project structure
```
sentinel-dashboard/
├── index.html      # markup for all three views (overview / logs / settings)
├── css/
│   └── style.css   # design tokens + all styling, mobile breakpoints included
├── js/
│   └── app.js       # view switching, mobile drawer, gauge animation, log data
└── README.md
```

## Wiring it up to a real bot
All the data on the page is mock data so the UI works out of the box. To connect it to your actual bot:

- **Security score / card stats** — replace the hardcoded values in `index.html` and the `SCORE` constant in `js/app.js` with data fetched from your bot's API (e.g. `fetch('/api/guilds/:id/security')`).
- **Moderation logs** — replace the `LOG_EVENTS` array in `js/app.js` with events from your bot's database, ideally over a websocket for live updates.
- **Settings cards** — the toggles/selects are visual only right now; hook their `change` events up to your bot's settings endpoint (e.g. `PATCH /api/guilds/:id/settings`).
- **Auth** — this is a static front-end with no auth. Put it behind your bot's OAuth2 (Discord login) flow before deploying for real users.

## Customizing the theme
Every color, font, and radius lives at the top of `css/style.css` under `:root`. Change the `--good` / `--warn` / `--danger` / `--accent` variables to reskin the whole dashboard.
