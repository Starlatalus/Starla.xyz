/* =========================================================
   SENTINEL dashboard — demo interactivity
   All data below is mock data for UI demonstration.
   Wire the TODOs to your bot's real API / websocket.
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- View switching (sidebar nav) ---------- */
  const navItems = document.querySelectorAll('[data-view]');
  const views = document.querySelectorAll('.view');

  function showView(name){
    views.forEach(v => v.classList.toggle('is-active', v.id === `view-${name}`));
    navItems.forEach(n => {
      if (n.classList.contains('nav__item')) {
        n.classList.toggle('is-active', n.dataset.view === name);
      }
    });
    closeSidebar();
  }

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      showView(item.dataset.view);
    });
  });

  /* ---------- Mobile sidebar drawer ---------- */
  const sidebar = document.getElementById('sidebar');
  const scrim = document.getElementById('scrim');
  const hamburger = document.getElementById('hamburger');

  function openSidebar(){ sidebar.classList.add('is-open'); scrim.classList.add('is-open'); }
  function closeSidebar(){ sidebar.classList.remove('is-open'); scrim.classList.remove('is-open'); }

  hamburger?.addEventListener('click', openSidebar);
  scrim?.addEventListener('click', closeSidebar);

  /* ---------- Security score gauge ---------- */
  const SCORE = 87; // TODO: pull live from bot API
  const arc = document.getElementById('gauge-arc');
  const scoreNumber = document.getElementById('score-number');

  // Animate the ring on load
  requestAnimationFrame(() => {
    arc.style.strokeDasharray = `${SCORE} 100`;
  });

  // Colour the ring/number based on score band
  function scoreColor(score){
    if (score >= 80) return 'var(--good)';
    if (score >= 55) return 'var(--warn)';
    return 'var(--danger)';
  }
  arc.style.stroke = scoreColor(SCORE);
  scoreNumber.textContent = SCORE;

  /* ---------- Mock log data ---------- */
  const LOG_EVENTS = [
    { type:'antinuke', level:'bad',  text:'Blocked mass-ban attempt by <b>@sketchy_user</b> (6 bans / 8s)', time:'2m ago' },
    { type:'backup',   level:'good', text:'Snapshot completed — roles, channels, permissions saved', time:'14m ago' },
    { type:'automod',  level:'warn', text:'Deleted spam message from <b>@newacct2291</b> in #general', time:'22m ago' },
    { type:'mod',      level:'good', text:'<b>@Riven</b> issued a 24h timeout to <b>@lag_gremlin</b>', time:'41m ago' },
    { type:'automod',  level:'warn', text:'Blocked invite link posted in #welcome', time:'1h ago' },
    { type:'antinuke',  level:'bad', text:'Webhook created and instantly deleted — flagged as suspicious', time:'2h ago' },
    { type:'mod',      level:'good', text:'<b>@Kesh</b> updated AutoMod slur filter word list', time:'3h ago' },
    { type:'backup',   level:'good', text:'Manual snapshot triggered by <b>@Owner</b>', time:'5h ago' },
    { type:'automod',  level:'warn', text:'Muted <b>@raid_bot_42</b> for rapid message spam (18 msgs / 5s)', time:'6h ago' },
    { type:'antinuke', level:'bad',  text:'Blocked role permission escalation on <b>@mod_trainee</b>', time:'8h ago' },
    { type:'mod',      level:'good', text:'<b>@Riven</b> banned <b>@tokenscam_bot</b>', time:'11h ago' },
    { type:'backup',   level:'good', text:'Snapshot completed — roles, channels, permissions saved', time:'1d ago' },
  ];

  const dotClass = { good:'feed-dot--good', warn:'feed-dot--warn', bad:'feed-dot--bad' };
  const tagClass = { antinuke:'tag-antinuke', automod:'tag-automod', mod:'tag-mod', backup:'tag-backup' };
  const tagLabel = { antinuke:'ANTI-NUKE', automod:'AUTOMOD', mod:'MANUAL', backup:'BACKUP' };

  /* ---------- Preview feed (overview page) ---------- */
  const feedPreview = document.getElementById('feed-preview');
  feedPreview.innerHTML = LOG_EVENTS.slice(0, 5).map(ev => `
    <div class="feed-row">
      <span class="feed-dot ${dotClass[ev.level]}"></span>
      <span class="feed-text">${ev.text}</span>
      <span class="feed-time">${ev.time}</span>
    </div>
  `).join('');

  /* ---------- Full terminal-style log (logs page) ---------- */
  const terminal = document.getElementById('terminal-feed');
  const filterBar = document.getElementById('log-filters');

  function stripHtml(str){ return str.replace(/<[^>]*>/g, s => s.includes('/') ? '' : ''); }

  function renderTerminal(filter){
    const rows = LOG_EVENTS.filter(ev => filter === 'all' || ev.type === filter);
    terminal.innerHTML = rows.map(ev => `
      <div class="term-line">
        <span class="t">[${ev.time}]</span>
        <span class="${tagClass[ev.type]}">${tagLabel[ev.type]}</span>
        <span> — ${ev.text.replace(/<b>|<\/b>/g,'')}</span>
      </div>
    `).join('') + `<div class="term-line"><span class="t">sentinel@wraithbound:~$</span> <span class="term-cursor"></span></div>`;
  }

  renderTerminal('all');

  filterBar?.addEventListener('click', (e) => {
    const chip = e.target.closest('.filter-chip');
    if (!chip) return;
    filterBar.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('is-active'));
    chip.classList.add('is-active');
    renderTerminal(chip.dataset.filter);
  });

  /* ---------- Buttons (demo feedback only) ---------- */
  const rescanBtn = document.getElementById('btn-rescan');
  rescanBtn?.addEventListener('click', () => {
    rescanBtn.textContent = 'Sweeping…';
    rescanBtn.disabled = true;
    // TODO: call your bot's real "run security sweep" endpoint here
    setTimeout(() => {
      rescanBtn.textContent = 'Run sweep';
      rescanBtn.disabled = false;
    }, 1400);
  });

  const backupBtn = document.getElementById('btn-backup-now');
  backupBtn?.addEventListener('click', () => {
    const original = backupBtn.textContent;
    backupBtn.textContent = 'Backing up…';
    // TODO: call your bot's real "create snapshot" endpoint here
    setTimeout(() => { backupBtn.textContent = 'Done ✓'; }, 1000);
    setTimeout(() => { backupBtn.textContent = original; }, 2600);
  });

  /* ---------- Hash-based deep linking (optional nicety) ---------- */
  const initial = location.hash.replace('#', '');
  if (['overview','logs','settings'].includes(initial)) showView(initial);
});
